#!/usr/bin/perl

#========================================================================
#
#               FILE: molExtracter.pl
#
#               USAGE: molExtracter.pl
#
#         DESCRIPTION: This script extracts molecules based on the ids given in an input file. 
#
#             OPTIONS: -----
#       REQURIREMENTS: runs with the parallelPLANTS.sh script
#                BUGS: -----
#               NOTES: -----
#             AUTHORS: Varun Khanna, varun.khanna@flinders.edu.au
#        ORGANIZATION: Flinders University
#             VERSION: 1.0
#             CREATED: 19-March-2017
#            REVISION: mol2 extraction was added
#                CITE: If use this script please cite Dr Varun Khanna
#========================================================================
use warnings;
use strict;

my @indexArray = ();
my $i =0;
my $idfile = 'tempindexFile'; #<STDIN>;
# Open and read the file into array
open(IDFILE, $idfile) || die "No file called tempindexFile found\n";
while (my $line = <IDFILE>)
{
	$indexArray[$i] = $line;
	$i++;
}
close(IDFILE);

my $mol2file = $ENV{'FROMFILE'}; #<STDIN>;
chomp($mol2file);
open(NEW,">extractedFile")|| die "Can't open file for writing\n";
open(MOL2, $mol2file) || die "No such file found\n";
for my $index (@indexArray)
{
seek(MOL2,$index-18,0);
my $flag = 1;
	while (my $line = <MOL2>)
        {
        	if ($line=~ /MOLECULE/ && $flag == 0)
                {
                #end of the molecule
                last;
                }
		else
		{
                print NEW $line;
		$flag = 0;
		}
	}
}
close(MOL2);
close (NEW);
