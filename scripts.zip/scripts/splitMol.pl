#!/usr/bin/perl
#========================================================================
#
#               FILE: splitMol.pl
#
#               USAGE: splitMol.pl
#
#         DESCRIPTION: This script splits a file based on inputs
#
#             OPTIONS: -----
#       REQURIREMENTS: mol2 file which needs to be split
#			
#                BUGS: -----
#               NOTES: -----
#             AUTHORS: Varun Khanna, varun.khanna@flinders.edu.au
#        ORGANIZATION: Vaxine Pvt Ltd
#             VERSION: 1.0
#             CREATED: 10-March-2017
#            REVISION: 
#                CITE: If use this script please cite Dr Varun Khanna
#========================================================================
use warnings;
use strict;

my $mol2file = $ENV{'LIGANDFILE'};

chomp($mol2file);
open(MOL2, $mol2file) || die "No such file found\n";

system "sed -n '/@<TRIPOS>MOLECULE/{n;p}' $mol2file >ids";
system "grep -Fxb -f ids $mol2file | cut -f1 -d: >indexFile";

my @indexArray = ();
my $idfile = 'indexFile'; #<STDIN>;

# Open and read the file into array
open(IDFILE, "<$idfile") || die "No such file found\n";
@indexArray = <IDFILE>;

close(IDFILE) || die "Cannot close the $!\n";

#print "Please enter the number of file splits you want\n";
my $split = $ENV{'LIGANDSPLITS'};
chomp($split);

my $chunk=int(scalar(@indexArray)/$split);
my $lastchunk = $chunk + (scalar(@indexArray)-($chunk * $split));
my @chunkArray = ();
@chunkArray = (@chunkArray, (($chunk) x ($split-1)), $lastchunk);

print "Wait splitting the file. This might take some time\n";
for (my $i =0; $i < scalar(@chunkArray); $i++)
{
my $count = 1;

open(NEW,">file". ($i+1) .".mol2")|| die "Can't open file for writing\n"; # Open the new chunk file

		while ( $count <= int($chunkArray[$i]) and (@indexArray))
        	{
			my $index = shift (@indexArray);
	        	seek(MOL2,$index-18,0);
        		my $flag = 1;
				while (my $line = <MOL2>)
                		{
                        		if ($line=~ /MOLECULE/ && $flag == 0)
                        		{
					$count++;
                        		#end of the molecule
                        		last;
                        		}
                        		else
                        		{
                        		print NEW $line;
                        		$flag = 0;
                        		}
                		}
        		
		}
		close(NEW); # end of the chunk
	#	sleep(1)		
}
unlink 'ids';
unlink $idfile;
print "Done spliting !!\n";

